package com.lti.service;

import java.util.List;

import com.lti.model.Language;

public interface LanguageService {
public List<Language> listLanguages();

public List<Language> getLanguageByLanguageId(Long languageId);
}