package com.lti.service;

import java.util.List;

import com.lti.model.Admin;

public interface AdminService {
public List<Admin> validateLoginAdmin(String adminEmail, String password);

public List<Admin> getAdminByAdminEmail(String adminEmail);
}
