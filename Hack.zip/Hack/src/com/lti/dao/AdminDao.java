package com.lti.dao;

import java.util.List;

import com.lti.model.Admin;

public interface AdminDao {
public List<Admin> validateLoginAdmin(String adminEmail, String password);

public List<Admin> getAdminByAdminEmail(String adminEmail);
}
