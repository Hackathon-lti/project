package com.lti.dao;

import java.util.List;

import com.lti.model.Language;

public interface LanguageDao {
public List<Language> listLanguages();

public List<Language> getLanguageByLanguageId(Long languageId);
}
