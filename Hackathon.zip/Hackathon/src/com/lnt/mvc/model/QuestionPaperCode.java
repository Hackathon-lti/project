/*package com.lnt.mvc.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class QuestionPaperCode {
	@Id
	@Column(name="ques_paper_code_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
private int ques_paper_code_id;

private int level;

@OneToMany(cascade = CascadeType.ALL, mappedBy = "topic")
Topic topic;
public int getQues_paper_code_id() {
	return ques_paper_code_id;
}
public void setQues_paper_code_id(int ques_paper_code_id) {
	this.ques_paper_code_id = ques_paper_code_id;
}
public int getLevel() {
	return level;
}
public void setLevel(int level) {
	this.level = level;
}
public Topic getTopic() {
	return topic;
}
public void setTopic(Topic topic) {
	this.topic = topic;
}
public QuestionPaperCode( int level, Topic topic) {
	super();
	
	this.level = level;
	this.topic = topic;
}
@Override
public String toString() {
	return "QuestionPaperCode [ques_paper_code_id=" + ques_paper_code_id + ", level=" + level + ", topic=" + topic
			+ "]";
}
public QuestionPaperCode() {
	super();
}





}
*/