/*package com.lnt.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Topic {
	@Id
	@Column(name="topic_id")

    @GeneratedValue(strategy = GenerationType.AUTO)
private int topic_id;
private String language;






public int getTopic_id() {
	return topic_id;
}
public void setTopic_id(int topic_id) {
	this.topic_id = topic_id;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
public Topic(String language) {
	super();
	
	this.language = language;
}
@Override
public String toString() {
	return "Topic [topic_id=" + topic_id + ", language=" + language + "]";
}
public Topic() {
	super();
}


}





*/