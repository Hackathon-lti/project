/*package com.lnt.mvc.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class QuestionPaper {
	

	@OneToOne(cascade = CascadeType.ALL, mappedBy = "questionPaperCode")
	private QuestionPaperCode questionPaperCode;
	@Id
	@Column(name="questionPaperId")
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int questionPaperId;
	private String ques_description;  
	
	@OneToMany
	private Set<Question> questions;
	
	
	
	
	
	
	
	
	
	
	
	
	public QuestionPaperCode getQuestionPaperCode() {
		return questionPaperCode;
	}

	public void setQuestionPaperCode(QuestionPaperCode questionPaperCode) {
		this.questionPaperCode = questionPaperCode;
	}

	public int getQuestionPaperId() {
		return questionPaperId;
	}

	public void setQuestionPaperId(int questionPaperId) {
		this.questionPaperId = questionPaperId;
	}

	public String getQues_description() {
		return ques_description;
	}

	public void setQues_description(String ques_description) {
		this.ques_description = ques_description;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public QuestionPaper(QuestionPaperCode questionPaperCode, int questionPaperId, String ques_description,
			Set<Question> questions) {
		super();
		this.questionPaperCode = questionPaperCode;
		this.questionPaperId = questionPaperId;
		this.ques_description = ques_description;
		this.questions = questions;
	}

	@Override
	public String toString() {
		return "QuestionPaper [questionPaperCode=" + questionPaperCode + ", questionPaperId=" + questionPaperId
				+ ", ques_description=" + ques_description + ", questions=" + questions + "]";
	}

	public QuestionPaper() {
		super();
	}
	

    }


*/