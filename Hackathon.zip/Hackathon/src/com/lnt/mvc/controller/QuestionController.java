package com.lnt.mvc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.exception.CustomException;


import com.lnt.mvc.model.Question;

import com.lnt.mvc.service.IQuestionService;


@Controller
public class QuestionController {
	@Autowired
private IQuestionService questionService;

//@Qualifier(value = "questionService")
public void setQuestionService(IQuestionService qs) {
	this.questionService = qs;
}
/*@Autowired
private IAnswerService answerService;

	public void setAnswerService(IAnswerService answerService) {
		this.answerService = answerService;
	}*/

//@ExceptionHandler(CustomException.class)
public ModelAndView handlePersonNotFoundException(CustomException ex) {
	Map<String, CustomException> model = new HashMap<String, CustomException>();
	model.put("exception", ex);
	return new ModelAndView("error", model);

}

//@ExceptionHandler(Exception.class)
public ModelAndView handleException(Exception ex) {
	Map<String, Exception> model = new HashMap<String, Exception>();
	model.put("exception", ex);
	return new ModelAndView("error", model);

}

@RequestMapping(value = "/questions", method = RequestMethod.GET)
public String listQuestions(Model model) {

	model.addAttribute("ques", new Question());// model
	model.addAttribute("listQuestions", 
			this.questionService.listQuestions());
	return "question";// view name
}

// For add and update person both
@RequestMapping(value = "/question/add", 
		method = RequestMethod.POST)
//@ExceptionHandler({ CustomException.class })
public String addQuestion(
		@ModelAttribute ("ques")
		@Valid Question question,
		BindingResult result,  
		Model model) {
	if (!result.hasErrors()) {
		if (question.getQuestion_id() == 0) {
			// new person, add it
			this.questionService.addQuestion(question);
		} else {
			// existing person, call update
			this.questionService.updateQuestion(question);
		}
		return "redirect:/questions";
	}
	model.addAttribute("listQuestions", this.questionService.listQuestions());
	return "question";
		}

	
	


@RequestMapping("/delete/{question_id}")
//@ExceptionHandler({ CustomException.class })
public String deleteQuestion(@PathVariable("question_id") int question_id) throws CustomException {
	if (question_id < 0) {
		throw new CustomException("Given Id Not Found","404");
	} else {
		this.questionService.deleteQuestion(question_id);
	}
	return "redirect:/questions";
}

@RequestMapping("/edit/{question_id}")
public String showEditQuestionPage(
		@PathVariable("question_id") int question_id, Model model) {
	Question questionObj = 
			this.questionService.getQuestionByQuestion_id(question_id);
	model.addAttribute("question", questionObj);
	List<Question> questionListObj =
			this.questionService.listQuestions();
	model.addAttribute("listQuestions", questionListObj);
	return "question";// view name
}
//Answer
/*@RequestMapping(value = "/answers", method = RequestMethod.GET)
public String listAnswers(Model model) {
	
	model.addAttribute("answer", new Answer());// model
	
	return "question";// view name
}*/

// For add and update person both
/*@RequestMapping(value = "/answer/add", 
		method = RequestMethod.POST)
//@ExceptionHandler({ CustomException.class })
public String addAnswer(
		@ModelAttribute("answer") 
		@Valid Answer a, 
		BindingResult result1, 
		Model model) {
	System.out.println("hhgjf");
	if (!result1.hasErrors()) {
	
		if (a.getAns_id() == 0) {
			// new question, add it
			
			this.answerService.addAnswer(a);
		} else {
			// existing person, call update
			this.answerService.updateAnswer(a);
		}
			return "redirect:/questions";
		}
		
	
	model.addAttribute("listAnswers", this.answerService.listAnswers());
	return "answer";
	
}*/


@RequestMapping("/showErrorPage/error")
//@ExceptionHandler(Exception.class)
public ModelAndView exception(Exception e) {

	ModelAndView mav = new ModelAndView("error");// view name
	mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
	mav.addObject("exMessage", e.getMessage());// model for ex msg
	return mav;
}



}