package com.lnt.mvc.dao;

import java.util.List;


import com.lnt.mvc.model.User;

public interface IUserDao {
	public void addUser(User u);//insert
	public void updateUser(User u);//update/modify
	public List<User> listUsers();//retrieve/listAll
	public User getUserById(int id);
}
