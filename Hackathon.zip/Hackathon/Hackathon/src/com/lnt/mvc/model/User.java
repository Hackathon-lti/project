package com.lnt.mvc.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table
public class User {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
private Integer id;
@Column(name="Fullname")
@NotEmpty(message = "Name cannot be empty!")
private String name;
@Column(name="Email_id")
@NotEmpty(message = "Email cannot be empty!")
private String email;
@Column(name="Password")
@NotEmpty(message = "Password cannot be empty!")
private String password;
@Column(name="Mobile No:")
@Size(max = 10, 
message = " Mobile number entered is invalid. It must be of 10 digit.")
private int mobile;
@Column(name="City")
@NotEmpty(message = "City cannot be empty!")
private String city;
@Column(name="state")
@NotEmpty(message = "State cannot be empty!")
private String state;
@Column(name="Qualification")
@NotEmpty(message = "Qualification cannot be empty!")
private String qualification;
@Column(name="Date_of_Birth")
@NotEmpty(message = "DOB cannot be empty!")
private Date dateOfBirth;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getMobile() {
	return mobile;
}
public void setMobile(int mobile) {
	this.mobile = mobile;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public User(Integer id, String name, String email, String password, int mobile, String city, String state,
		String qualification, Date dateOfBirth) {
	super();
	this.id = id;
	this.name = name;
	this.email = email;
	this.password = password;
	this.mobile = mobile;
	this.city = city;
	this.state = state;
	this.qualification = qualification;
	this.dateOfBirth = dateOfBirth;
}
@Override
public String toString() {
	return "User [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", mobile=" + mobile
			+ ", city=" + city + ", state=" + state + ", qualification=" + qualification + ", dateOfBirth="
			+ dateOfBirth + "]";
}
public User() {
	super();
}

}
