package com.lnt.mvc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.exception.CustomException;
import com.lnt.mvc.model.User;
import com.lnt.mvc.service.IUserService;

@Controller
public class UserController {
	private IUserService userService;

	@Autowired
	@Qualifier(value = "userService")
	public void setUserService(IUserService us) {
		this.userService = us;
	}

	@ExceptionHandler(CustomException.class)
	public ModelAndView handleUserNotFoundException(CustomException ex) {
		Map<String, CustomException> model = new HashMap<String, CustomException>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex) {
		Map<String, Exception> model = new HashMap<String, Exception>();
		model.put("exception", ex);
		return new ModelAndView("error", model);

	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public String listUsers(Model model) {
		model.addAttribute("user", new User());// model
		model.addAttribute("listUsers", 
				this.userService.listUsers());
		return "user";// view name
	}

	// For add and update person both
	@RequestMapping(value = "/user/add", 
			method = RequestMethod.POST)
	@ExceptionHandler({ CustomException.class })
	public String addUser(
			@ModelAttribute("user") 
			@Valid User u, 
			BindingResult result, 
			Model model) {
		if (!result.hasErrors()) {
			if (u.getId() == null) {
				// new person, add it
				this.userService.addUser(u);
			} else {
				// existing person, call update
				this.userService.updateUser(u);
			}
			return "redirect:/users";
		}
		model.addAttribute("listUsers", this.userService.listUsers());
		return "user";

	}

	

	@RequestMapping("/edit/{id}")
	public String showEditUserPage(
			@PathVariable("id") int id, Model model) {
		User userObj = 
				this.userService.getUserById(id);;
		model.addAttribute("user", userObj);
		List<User> userListObj =
				this.userService.listUsers();
		model.addAttribute("listUsers", userListObj);
		return "user";// view name
	}

	@RequestMapping("/showErrorPage/error")
	@ExceptionHandler(Exception.class)
	public ModelAndView exception(Exception e) {

		ModelAndView mav = new ModelAndView("error");// view name
		mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
		mav.addObject("exMessage", e.getMessage());// model for ex msg
		return mav;
	}
}
