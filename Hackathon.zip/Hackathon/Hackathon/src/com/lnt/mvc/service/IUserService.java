package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.model.User;

public interface IUserService {
	public void addUser(User u);//insert
	public void updateUser(User u);//update/modify
	public List<User> listUsers();//retrieve/listAll
	public User getUserById(int id);
}
