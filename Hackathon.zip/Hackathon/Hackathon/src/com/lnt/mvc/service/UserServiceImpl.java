package com.lnt.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.IUserDao;
import com.lnt.mvc.model.User;
@Service
public class UserServiceImpl implements IUserService{
	private IUserDao userDao;
	@Autowired
	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}
	@Override
	@Transactional
	public void addUser(User u) {
		// TODO Auto-generated method stub
		this.userDao.addUser(u);
	}

	@Override
	@Transactional
	public void updateUser(User u) {
		// TODO Auto-generated method stub
		this.userDao.updateUser(u);
	}

	@Override
	@Transactional
	public List<User> listUsers() {
		// TODO Auto-generated method stub
		return this.userDao.listUsers();
		
	}
	@Override
	@Transactional
	public User getUserById(int id) {
		return this.userDao.getUserById(id);
	}
}
